
from flask import Flask, render_template, request, redirect, session, url_for
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'clave_secreta'
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

posts = []

@app.route('/')
def index():
    return render_template('index.html', posts=posts)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        tipo = request.form['type']
        content = ''
        if tipo == 'text':
            content = request.form['text']
        elif 'file' in request.files:
            f = request.files['file']
            content = f.filename
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename))
        posts.append({
            'username': session.get('username', 'Anónimo'),
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M"),
            'type': tipo,
            'content': content,
            'likes': 0,
            'comments': []
        })
        return redirect('/')
    return '''
    <form method="post" enctype="multipart/form-data">
      <input type="radio" name="type" value="text" checked> Texto
      <input type="radio" name="type" value="image"> Imagen<br>
      <textarea name="text" placeholder="Escribí algo"></textarea><br>
      <input type="file" name="file"><br>
      <button>Subir</button>
    </form>
    '''

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['username'] = request.form['username']
        return redirect('/')
    return '''
    <form method="post">
      Usuario: <input name="username"><br>
      <button>Iniciar sesión</button>
    </form>
    '''

@app.route('/register', methods=['GET', 'POST'])
def register():
    return redirect('/login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
